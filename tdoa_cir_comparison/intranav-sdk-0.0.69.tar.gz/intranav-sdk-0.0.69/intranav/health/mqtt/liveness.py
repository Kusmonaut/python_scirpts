from paho.mqtt.client import Client, MQTTMessage
import paho.mqtt.publish as publish
import subprocess
import logging
import os

ID_CMD = "cat /etc/hostname"


class LivenessMqtt:
    mqtt_client: Client = None
    container_id: str = ""
    logger = logging.getLogger(__name__)

    def __init__(self, mqtt_client: Client):
        self.mqtt_client = mqtt_client

        if os.environ.get("HOSTNAME"):
            self.container_id = os.environ.get("HOSTNAME")
        else:
            try:
                self.container_id = (
                    subprocess.check_output(ID_CMD, shell=True)
                    .decode("utf-8")
                    .rstrip("\n\r")
                )
            except subprocess.CalledProcessError:
                pass

    def start(self):
        if self.mqtt_client is None:
            raise NotInitialized("Initialize the class before running start.")
        if not self.mqtt_client.is_connected:
            raise ClientNotConnected(
                "Please make sure the MQTT Client is connected to the broker."
            )
        else:
            if self.container_id == "":
                self.logger.info(
                    "Service is not running in Docker container. Healthcheck is not active."
                )
                return
            topic = f"service/{self.container_id}/liveness"
            self.mqtt_client.subscribe(topic)
            self.logger.info("Subscribed to health check topic.")
            self.mqtt_client.message_callback_add(topic, self.on_message)

    @staticmethod
    def on_message(client: Client, userdata, message: MQTTMessage):
        response_topic = message.topic + "/response"
        client.publish(response_topic, "alive")


class NotInitialized(Exception):
    pass


class ClientNotConnected(Exception):
    pass


class NotInDockerContainer(Exception):
    pass
