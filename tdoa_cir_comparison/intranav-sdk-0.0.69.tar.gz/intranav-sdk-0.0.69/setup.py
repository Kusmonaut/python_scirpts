from setuptools import setup, find_packages

from intranav import __VERSION__


with open("README.md", "r") as readme_file:
    readme = readme_file.read()

install_requires = [
    "libscrc>=1.7.1",
    "paho-mqtt>=1.5.1",
    "protobuf>=3.17.3",
    "requests>=2.26.0",
]

if __name__ == "__main__":
    setup(
        name="intranav-sdk",
        author_email="sdk@intranav.com",
        author="Intranav GmbH",
        description="Python API to talk to the IntraNav Platform",
        install_requires=install_requires,
        long_description_content_type="text/markdown",
        long_description=readme,
        package_data={"": ["*.pyi"]},
        packages=find_packages(),
        platforms=["Linux", "Mac OSX", "Windows", "Unix"],
        python_requires=">=3.6",
        url="https://intranav.com",
        version=__VERSION__,
    )
