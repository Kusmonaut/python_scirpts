# IntraNav Python SDK

## Create an new release
- Increment `__VERSION__` in `intranav/__init__.py`
- Commit changes to `master`
- Create a Tag with corresponding version number:
```
git push
git tag v{MAJOR}.{MINOR}.{PATCH}
git push --tags
```
