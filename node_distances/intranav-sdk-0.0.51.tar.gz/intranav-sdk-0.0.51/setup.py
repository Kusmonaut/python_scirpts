from setuptools import setup, find_packages

from intranav import __VERSION__


with open("README.md", "r") as readme_file:
    readme = readme_file.read()

install_requires = [
    "requests>=2.24.0",
    "paho-mqtt>=1.5.1",
    "libscrc>=1.5",
    "protobuf>=3.13.0",
]

if __name__ == "__main__":
    setup(
        name="intranav-sdk",
        author_email="sdk@intranav.com",
        author="Intranav GmbH",
        description="Python API to talk to the IntraNav Platform",
        install_requires=install_requires,
        long_description_content_type="text/markdown",
        long_description=readme,
        package_data={"": ["*.pyi"]},
        packages=find_packages(),
        platforms=["Linux", "Mac OSX", "Windows", "Unix"],
        python_requires=">=3.6",
        url="https://intranav.com",
        version=__VERSION__,
    )
