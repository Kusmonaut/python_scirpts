# Fix for protobuf
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from typing import List

from libscrc import kermit
from intranav.proto.inav_full_pb2 import IntranavMessage
from google.protobuf.internal.decoder import _DecodeVarint32
from google.protobuf.message import DecodeError


MIN_MESSAGE_SIZE = 6
START_OF_MESSAGE = 0x2
START_OF_PAYLOAD = 3
END_OF_MESSAGE = 0x3
END_OF_CRC = 5


class Decoder:
    def __init__(self):
        self._buffer = b""

    def clear(self):
        self._buffer = b""

    def decode(self, b: bytes) -> List[IntranavMessage]:
        # Append new data to buffer
        self._buffer += b

        messages: List[IntranavMessage] = []

        while len(self._buffer) > MIN_MESSAGE_SIZE:

            # Search for START_OF_MESSAGE
            try:
                while self._buffer[0] != START_OF_MESSAGE:
                    self._buffer = self._buffer[1:]
            except IndexError:
                break

            # Buffer is to small for a whole message
            if len(self._buffer) <= MIN_MESSAGE_SIZE:
                break

            # Check payload size
            payload_len = int.from_bytes(self._buffer[1:3], byteorder="little")
            if len(self._buffer) < payload_len + MIN_MESSAGE_SIZE:
                # Truncated message
                break

            # Check END_OF_MESSAGE
            if self._buffer[payload_len + MIN_MESSAGE_SIZE - 1] != END_OF_MESSAGE:
                # Missing END_OF_MESSAGE
                try:
                    self._buffer = self._buffer[1:]
                    continue
                except IndexError:
                    break

            payload = self._buffer[START_OF_PAYLOAD : payload_len + START_OF_PAYLOAD]
            payload_crc = int.from_bytes(
                self._buffer[payload_len + START_OF_PAYLOAD : payload_len + END_OF_CRC],
                byteorder="little",
            )

            if kermit(payload) != payload_crc:
                # CRC failed -> discard message
                self._buffer = self._buffer[payload_len + MIN_MESSAGE_SIZE :]
                continue

            try:
                # Parse Payload as Protobuf
                msg = IntranavMessage()
                proto_len, proto_start = _DecodeVarint32(payload, 0)
                proto_parsed = msg.ParseFromString(
                    payload[proto_start : proto_start + proto_len]
                )
                if proto_parsed != proto_len:
                    raise DecodeError

                messages.append(msg)

            except DecodeError:
                pass

            self._buffer = self._buffer[payload_len + MIN_MESSAGE_SIZE :]

        return messages
