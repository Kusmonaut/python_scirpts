"""
Names for IntraNav Devices
"""
from intranav.constants.devices import (
    UWB_TAG_ASSET_COIN_HW_ID,
    UWB_TAG_ASSET_HW_ID,
    UWB_TAG_MICRO_HW_ID,
    UWB_TAG_VEHICLE_HW_ID,
)

TAG_DEVICE_NAMES = {
    UWB_TAG_ASSET_HW_ID: "Asset Tag Pro",
    UWB_TAG_ASSET_COIN_HW_ID: "LTLS Tag",
    UWB_TAG_MICRO_HW_ID: "Asset Tag Micro",
    UWB_TAG_VEHICLE_HW_ID: "Vehicle Tag",
}
