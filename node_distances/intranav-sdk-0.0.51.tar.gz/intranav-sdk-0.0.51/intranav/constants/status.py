"""
Status for IntraNav Devices
"""
from enum import Enum

class DeviceStatus(Enum):
    UNKNOWN = 1
    ONLINE = 2
    OFFLINE = 3
    BATTERY_LOW = 4
    BATTERY_EMPTY = 5
    NEW_DEVICE = 6
    WARNING = 7
    MOVED = 8
    SHOCKED = 9
