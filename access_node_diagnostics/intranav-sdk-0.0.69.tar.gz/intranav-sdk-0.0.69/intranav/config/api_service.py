import logging
import json
import os
from requests import Session
from paho.mqtt.client import Client, MQTTMessage
from intranav.config.user_config import UserConfig
from intranav.helper import normalize_api_url

log = logging.getLogger(__name__)


class ConfigAPIService:
    def __init__(self, session: Session, api_base: str, service_name: str):
        """Constructor

        Parameters:

        session (Session): Preconfigured requests.Session object with approprite authorization

        api_base (str): Intranav platform API base url for http requests.

        service_name: str, user_config: UserConfig, mqtt_client:Client

        Returns:

            An instance object of this this class
        """
        super().__init__()
        self.session = session
        self.api_base = api_base
        self.service_name = service_name
        self.callback = None

    def start(self, mqtt_client: Client, user_config: UserConfig):
        update_config = os.getenv("UPDATE_USER_CONFIG", "false") in [
            "true",
            "True",
            "yes",
            "1",
        ]
        self.__initialize_configurations(user_config, update_config)
        self.__subscribe_changes(mqtt_client, user_config)

    def add_callback(self, callback):
        self.callback = callback

    def remove_callback(self, callback):
        self.callback = None

    def __initialize_configurations(self, user_config, update_config):
        values = self.__get_configuration()

        if values:
            if update_config:
                res = self.__update_configuration(user_config.get_values())
                if not res:
                    log.warn("Could not update service configuration!")
                else:
                    log.info("Service configuration updated :")
                log.info(self.service_name + " : " + str(user_config.get_values()))
                return

            new_configuration = user_config.get_difference_by_keys(values)
            if bool(new_configuration):
                values.update(new_configuration)

                user_config.set_values(values)

                res = self.__update_configuration(user_config.get_values())
                if not res:
                    log.warn("Could not update service configuration!")
                else:
                    log.info("Service configuration updated :")
                log.info(self.service_name + " : " + str(user_config.get_values()))
            else:
                user_config.set_values(values)
                log.info("Service configuration :")
                log.info(self.service_name + " : " + str(user_config.get_values()))
        else:
            res = self.__register_service(user_config.get_values())
            if not res:
                log.warn("Could not create service configuration!")
            else:
                log.info("Service configuration created :")
            log.info(self.service_name + " : " + str(user_config.get_values()))

    def __get_configuration(self):
        url = self.api_base + f"/service-configs/{self.service_name}"
        try:
            r = self.session.get(url)
            if r.status_code == 200:
                config = r.json()
                values = config.get("values")
                return values
            else:
                return None
        except:
            return None

    def __update_configuration(self, configuration):
        url = self.api_base + f"/service-configs/{self.service_name}"
        try:
            r = self.session.put(
                url, json={"serviceName": self.service_name, "values": configuration}
            )
            if r.status_code == 200:
                return True
            else:
                return False
        except:
            return False

    def __register_service(self, configuration):
        url = self.api_base + "/service-configs"
        try:
            r = self.session.post(
                url, json={"serviceName": self.service_name, "values": configuration}
            )
            if r.status_code == 200:
                return True
            else:
                return False
        except:
            return False

    def __subscribe_changes(self, client: Client, user_config):
        # Subscribe to configuration changes
        topic = f"/api/service-configs"
        client.subscribe(topic)

        def on_message(client, userdata, message):
            self.__on_configuration_change(
                self.session,
                self.service_name,
                user_config,
                client,
                userdata,
                message,
                self.api_base,
            )
            if self.callback:
                try:
                    self.callback(client, userdata, message)
                except:
                    pass

        client.message_callback_add(
            topic,
            on_message,
        )
        log.info(f"Subscribed to {topic}")

    @staticmethod
    def __on_configuration_change(
        session,
        service_name,
        user_config,
        client: Client,
        userdata,
        message: MQTTMessage,
        api_base: str,
    ):
        configuration_change = json.loads(message.payload)
        event_type = configuration_change.get("eventType")
        name = configuration_change.get("id")
        if event_type == "updated" and name == service_name:
            configuration_change["url"] = normalize_api_url(
                configuration_change["url"], api_base
            )
            r = session.get(configuration_change["url"])
            configuration = r.json()
            values = configuration.get("values") or {}
            if bool(values):
                saved_all = user_config.update_values(values)
                if not saved_all:
                    try:
                        r = session.put(
                            configuration_change["url"],
                            json={
                                "serviceName": service_name,
                                "values": user_config.get_values(),
                            },
                        )
                    except:
                        pass
                log.info("Config updated : " + str(user_config.get_values()))
