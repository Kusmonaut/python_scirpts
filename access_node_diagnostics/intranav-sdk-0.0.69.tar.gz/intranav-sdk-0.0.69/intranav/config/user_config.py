import os

def get_env(var, default=""):
    return os.getenv(var, default) or default

class UserConfig:
    values: dict
    formatters: dict

    def __init__(self, values: dict, formatters: dict = {}):
        """Constructor

        Parameters:

        values (dict): Variable map with default(initial) values. Eg.::

            user_config_values = {
                "DELAY": DELAY
            }

        formatters (dict = {}): Variable map with formatter functions. If one exists for a key, 
        it will be called before updating the value of the key. Eg.::
        
            user_config_formatters = {
                "DELAY": lambda val: 1.0 if float(val or '1') < 1 else float(val or '1')
            }

        Returns:

            An instance object of this this class
        """
        super().__init__()
        self.values = values
        self.formatters = formatters

    def set_values(self, values: dict):
        """Setter

        Replaces current values map.

        Parameters:

        values (dict): Variable map with values
        """
        for key in values:
            if key in self.formatters:
                try:
                    self.values[key] = self.formatters[key](values[key])
                except:
                    pass
            else:
                self.values[key] = values[key]

    def get_values(self):
        """Getter

        Returns current values map.

        Returns:

        values (dict): Current values map.
        """
        return self.values

    def update_values(self, values: dict):
        """Update values

        Updates current values map with parameter values. Only the values
        that currently exists will be updated.

        Parameters:

        values (dict): Variable map with values

        Returns:
        saved_all (boolean): True if all new values are updated, False if any of the values failed formatting
        """
        saved_all = True
        for key in values:
            if key not in self.values:
                pass
            if key in self.formatters:
                try:
                    self.values[key] = self.formatters[key](values[key])
                except:
                    saved_all = False
            else:
                self.values[key] = values[key]
        
        return saved_all

    def get_difference_by_keys(self, values):
        """Get difference

        Returns the difference of the current value map with parameter map.
        Result is the partial map of the current map that the parameter map 

        Parameters:

        values (dict): Variable map with values
        """
        new_keys = {k: self.values[k] for k in set(self.values) - set(values)}
        for key in new_keys:
            if key in self.formatters:
                try:
                    new_keys[key] = self.formatters[key](values[key])
                except:
                    new_keys.update({key: self.values[key]})

        return new_keys
    
    def get_difference_by_values(self, values):
        """Get difference

        Returns the difference of the current value map with parameter map.

        Parameters:

        values (dict): Variable map with values
        """
        new_values = {}
        for key in self.values:
            if key in values:
                if key in self.formatters:
                    try:
                        val = self.formatters[key](values[key])
                        if val != self.values[key]:
                            new_values[key] = self.values[key]
                    except:
                        if val != self.values[key]:
                            new_values[key] = self.values[key]
                else:
                    val = values[key]
                    if val != self.values[key]:
                        new_values[key] = self.values[key]
            else:
                new_values[key] = self.values[key]

        return new_values

    def get_config(self, key):
        """Get Config

        Returns a value of a key from current values map.

        Parameters:

        key (str): Variable map with values
        """
        value = self.values[key] if key in self.values else None
        if value or value == 0:
            try:
                return self.formatters[key](value)
            except:
                return value
        else:
            if key in self.formatters:
                try:
                    return self.formatters[key](get_env[key])
                except:
                    return get_env(key)
            else:
                return get_env(key)
