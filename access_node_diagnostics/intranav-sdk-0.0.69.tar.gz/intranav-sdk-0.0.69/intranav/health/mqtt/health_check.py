import os
import sys
import subprocess
from threading import Timer
from paho.mqtt.client import Client, MQTTMessage

def get_env(var, default=""):
    return os.getenv(var, default) or default

HOSTNAME = get_env("HOSTNAME")
MQTT_HOST = get_env("MQTT_HOST", "localhost")
MQTT_PORT = int(get_env("MQTT_PORT", "1883"))
MQTT_USER = get_env("MQTT_USER", "qt_services")
MQTT_PASS = get_env("MQTT_PASS", "VXDY6KeqyTkJ5z8mqZm8")
LIVENESS_TIMEOUT = int(get_env("LIVENESS_TIMEOUT", "3"))

FAIL = False

def on_liveness_response(client: Client, userdata, message: MQTTMessage):
    print('Ok')
    client.disconnect()


def on_mqtt_connect(client: Client, userdata, flags, rc):
    global FAIL
    container_id = HOSTNAME
    if container_id == '':
        # Not in docker container
        client.disconnect()
        return
    topic = f"service/{container_id}/liveness"
    response_topic = f"service/{container_id}/liveness/response"

    client.subscribe(response_topic)
    client.message_callback_add(response_topic, on_liveness_response)

    client.publish(topic, 'alive?')

    t = Timer(LIVENESS_TIMEOUT,dead,(client,))
    t.daemon = True
    t.start()


def on_disconnect(client, userdata, rc):
    global FAIL
    if FAIL:
        os._exit(1)
    else:
        os._exit(0)

def dead(client):
    global FAIL
    print('Timeout')
    FAIL=True
    client.disconnect()


if __name__ == '__main__':

    mqtt_client: Client = Client(clean_session=True)
    mqtt_client.on_connect = on_mqtt_connect
    mqtt_client.on_disconnect = on_disconnect
    mqtt_client.username_pw_set(MQTT_USER, MQTT_PASS)

    mqtt_client.connect(MQTT_HOST, MQTT_PORT)
    mqtt_client.loop_forever()