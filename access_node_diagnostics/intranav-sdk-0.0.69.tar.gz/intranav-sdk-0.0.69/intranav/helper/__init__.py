from urllib.parse import urlparse


def normalize_api_url(url: str, api_base: str):
    # Normalize api_base such that it doesn't end with / and has no spaces
    # in front or at the end
    api_base = api_base.strip()
    while api_base.endswith("/"):
        api_base = api_base[:-1]

    endpoint = url.strip()
    if endpoint.startswith("http"):
        p = urlparse(endpoint)

        endpoint = p.path

        if p.params:
            endpoint = f"{endpoint};{p.params}"

        if p.query:
            endpoint = f"{endpoint}?{p.query}"

        if p.fragment:
            endpoint = f"{endpoint}#{p.fragment}"

        if endpoint.startswith("/api"):
            endpoint = endpoint[4:]

    return f"{api_base}{endpoint}"


if __name__ == "__main__":
    print(
        normalize_api_url(
            "http://backend:3000/api/devices/1", "https://cloud.intranav.io/api"
        )
    )

    print(
        normalize_api_url(
            "http://backend:3000/api/devices/1", "https://cloud.intranav.io/api/"
        )
    )
    print(
        normalize_api_url(
            "http://backend:3000/api/devices/1;param?start=1",
            "https://cloud.intranav.io/api/",
        )
    )
    print(
        normalize_api_url(
            "http://backend:3000/api/devices/1#data", "https://cloud.intranav.io/api/"
        )
    )
    print(
        normalize_api_url(
            "http://backend:3000/api/devices/1?start=1#data",
            "https://cloud.intranav.io/api/",
        )
    )

    print(normalize_api_url("/devices/1", "https://cloud.intranav.io/api"))
    print(normalize_api_url("/devices/1", "https://cloud.intranav.io/api/"))
    print(normalize_api_url("/devices/1", "https://cloud.intranav.io/api//"))
    print(normalize_api_url("/devices/1", "https://cloud.intranav.io/api "))
    print(normalize_api_url("/devices/1?start=1", "https://cloud.intranav.io/api "))
    print(
        normalize_api_url("/devices/1?start=1#data", "https://cloud.intranav.io/api ")
    )
    print(normalize_api_url("/devices/1#data", "https://cloud.intranav.io/api "))
