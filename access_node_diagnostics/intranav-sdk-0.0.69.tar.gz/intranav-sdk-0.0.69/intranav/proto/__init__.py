# Fix for protobuf
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from typing import List
import struct

from libscrc import kermit  # type: ignore
from intranav.proto.inav_full_pb2 import IntranavMessage
from google.protobuf.internal.decoder import _DecodeVarint32  # type: ignore
from google.protobuf.message import DecodeError


MIN_MESSAGE_SIZE = 6
START_OF_MESSAGE = 0x2
START_OF_PAYLOAD = 3
END_OF_MESSAGE = 0x3
END_OF_CRC = 5

# LEGACY_PAYLOADS
LEGACY_REPORT_TOA_EXT_ID = 0x34
LEGACY_REPORT_TOA_EXT_FORMAT = "<BQ5sHBHHhhhLHBB"
LEGACY_REPORT_TOA_EXT_LENGTH = struct.calcsize(LEGACY_REPORT_TOA_EXT_FORMAT)


class Decoder:
    def __init__(self):
        self._buffer = b""

    def clear(self):
        self._buffer = b""

    def decode(self, b: bytes, legacy: bool = False) -> List[IntranavMessage]:
        # Append new data to buffer
        self._buffer += b

        messages: List[IntranavMessage] = []

        while len(self._buffer) > MIN_MESSAGE_SIZE:

            # Search for START_OF_MESSAGE
            try:
                while self._buffer[0] != START_OF_MESSAGE:
                    self._buffer = self._buffer[1:]
            except IndexError:
                break

            # Buffer is to small for a whole message
            if len(self._buffer) <= MIN_MESSAGE_SIZE:
                break

            # Check payload size
            payload_len = int.from_bytes(self._buffer[1:3], byteorder="little")
            if len(self._buffer) < payload_len + MIN_MESSAGE_SIZE:
                # Truncated message
                break

            # Check END_OF_MESSAGE
            if self._buffer[payload_len + MIN_MESSAGE_SIZE - 1] != END_OF_MESSAGE:
                # Missing END_OF_MESSAGE
                try:
                    self._buffer = self._buffer[1:]
                    continue
                except IndexError:
                    break

            payload = self._buffer[START_OF_PAYLOAD : payload_len + START_OF_PAYLOAD]
            payload_crc = int.from_bytes(
                self._buffer[payload_len + START_OF_PAYLOAD : payload_len + END_OF_CRC],
                byteorder="little",
            )

            if kermit(payload) != payload_crc:
                # CRC failed -> discard message
                self._buffer = self._buffer[payload_len + MIN_MESSAGE_SIZE :]
                continue

            if legacy:
                try:
                    msg_type = payload[0]
                    if msg_type == LEGACY_REPORT_TOA_EXT_ID:
                        # Unpack message
                        (
                            seq_nr,
                            tag_eui_raw,
                            timestamp,
                            first_path,
                            _,  # ext_len,
                            state,
                            battery,
                            ax,
                            ay,
                            az,
                            pressure,
                            temp,
                            firmware,
                            hardware,
                        ) = struct.unpack(
                            LEGACY_REPORT_TOA_EXT_FORMAT,
                            payload[1 : 1 + LEGACY_REPORT_TOA_EXT_LENGTH],
                        )

                        msg = IntranavMessage()

                        msg.rtls_report_blink.blink.id = tag_eui_raw
                        msg.rtls_report_blink.blink.state = state
                        msg.rtls_report_blink.blink.battery = battery
                        msg.rtls_report_blink.blink.acceleration.acc_x = abs(ax)
                        msg.rtls_report_blink.blink.acceleration.acc_y = abs(ay)
                        msg.rtls_report_blink.blink.acceleration.acc_z = abs(az)
                        msg.rtls_report_blink.blink.pressure.pressure = pressure
                        msg.rtls_report_blink.blink.pressure.temp = abs(temp)
                        msg.rtls_report_blink.blink.fw = firmware
                        msg.rtls_report_blink.blink.hw = hardware

                        msg.rtls_report_blink.translated = True
                        msg.rtls_report_blink.sequence_number = seq_nr
                        msg.rtls_report_blink.first_path = first_path
                        msg.rtls_report_blink.tag_id = tag_eui_raw
                        msg.rtls_report_blink.timestamp = int.from_bytes(
                            timestamp, "little"
                        )

                        messages.append(msg)
                except:
                    pass

            else:
                try:
                    # Parse Payload as Protobuf
                    msg = IntranavMessage()
                    proto_len, proto_start = _DecodeVarint32(payload, 0)
                    proto_parsed = msg.ParseFromString(
                        payload[proto_start : proto_start + proto_len]
                    )
                    if proto_parsed != proto_len:
                        raise DecodeError

                    messages.append(msg)

                except DecodeError:
                    pass

            self._buffer = self._buffer[payload_len + MIN_MESSAGE_SIZE :]

        return messages
