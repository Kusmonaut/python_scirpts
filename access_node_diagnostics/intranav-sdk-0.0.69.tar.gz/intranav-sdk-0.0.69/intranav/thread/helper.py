import threading
import signal
import traceback
import logging


class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class ThreadStatus(object, metaclass=Singleton):
    def __init__(self):
        self._event: threading.Event = threading.Event()
        self._code: int = 0

        signal.signal(signal.SIGTERM, self._signal_handler)

    @property
    def event(self) -> threading.Event:
        return self._event

    @property
    def code(self) -> int:
        return self._code

    def excepted(self):
        self._event.set()
        self._code = 1
        traceback.print_exc()

    def _signal_handler(self, sig, frame):
        self._event.set()


def ensure_exception(func):
    def wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except Exception as ex:
            logging.error(ex, exc_info=ex)
            ThreadStatus().excepted()

    return wrapper
