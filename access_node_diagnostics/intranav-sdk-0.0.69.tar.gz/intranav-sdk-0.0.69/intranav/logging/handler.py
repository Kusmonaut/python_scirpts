import logging
import json

from requests import Session


class IntraNavHandler(logging.Handler):
    BLACKLIST = [
        "__class__",
        "__delattr__",
        "__dict__",
        "__dir__",
        "__doc__",
        "__eq__",
        "__format__",
        "__ge__",
        "__getattribute__",
        "__gt__",
        "__hash__",
        "__init__",
        "__init_subclass__",
        "__le__",
        "__lt__",
        "__module__",
        "__ne__",
        "__new__",
        "__reduce__",
        "__reduce_ex__",
        "__repr__",
        "__setattr__",
        "__sizeof__",
        "__str__",
        "__subclasshook__",
        "__weakref__",
        "args",
        "created",
        "exc_info",
        "exc_text",
        "filename",
        "funcName",
        "getMessage",
        "levelname",
        "levelno",
        "lineno",
        "module",
        "msecs",
        "msg",
        "name",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "stack_info",
        "thread",
        "threadName",
    ]

    def __init__(self, api_base: str, token: str, level = logging.NOTSET):
        logging.Handler.__init__(self, level)

        self._api_base = api_base
        self._token = token

        self._s = Session()
        self._s.headers.update({"Authorization": "Api-Key {}".format(self._token)})

    def emit(self, record: logging.LogRecord):

        data = {
            "type": record.levelname,
            "message": record.msg,
            "source": record.name,
            "timestamp": int(record.created * 1000),
            "data": {},
        }

        # Get extra data
        for extra_data in dir(record):
            if extra_data not in self.BLACKLIST:
                try:
                    data["data"][extra_data] = str(getattr(record, extra_data))
                except:
                    continue

        data["data"] = json.dumps(data["data"])

        try:
            self._s.post(f"{self._api_base}/events", json=data)
        except:
            pass
